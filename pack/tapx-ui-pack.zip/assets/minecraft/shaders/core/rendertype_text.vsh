#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

// TapX: animated text colours (see TextFx.kt). Everything else is vanilla.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 tapxHue(float h) {
    return clamp(abs(mod(h * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
}

// a -> b -> c -> a, p in [0, 1)
vec3 tapxLoop(vec3 a, vec3 b, vec3 c, float p) {
    float q = fract(p) * 3.0;
    if (q < 1.0) return mix(a, b, smoothstep(0.0, 1.0, q));
    if (q < 2.0) return mix(b, c, smoothstep(0.0, 1.0, q - 1.0));
    return mix(c, a, smoothstep(0.0, 1.0, q - 2.0));
}

vec3 fx(int kind, vec3 c1, vec3 c2, vec3 c3, float speed, float shine, float x, float t, bool top) {
    vec3 base;
    if (kind == 2) {
        base = mix(tapxHue(t * 0.12 * speed), vec3(1.0), 0.18);   // pastel rainbow, whole word at once
    } else if (kind == 1) {
        base = tapxLoop(c1, c2, c3, t * 0.12 * speed);              // fades through its colours
    } else {
        base = c1;
    }
    base *= 0.94 + 0.06 * sin(t * 2.2 * speed);                    // gentle breathing glow
    // candy gloss: each letter lighter at the top, a little deeper at the bottom
    base = top ? mix(base, vec3(1.0), 0.5) : base * 0.8;
    // soft shine sweeping left to right every few seconds
    float s = fract(x / 260.0 - t * 0.28 * speed);
    float band = smoothstep(0.0, 0.06, s) * (1.0 - smoothstep(0.06, 0.16, s));
    return mix(base, vec3(1.0), band * 0.55 * shine);
}

void main() {
    vec4 pos = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 col = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    float t = GameTime * 1200.0;
    float gs = max(1.0, floor(min(ScreenSize.x / 320.0, ScreenSize.y / 240.0)));
    float x = (pos.x / pos.w * 0.5 + 0.5) * ScreenSize.x / gs;
    // glyph quads are drawn top-left, bottom-left, bottom-right, top-right
    int corner = gl_VertexID % 4;
    bool top = corner == 0 || corner == 3;
    if (c == ivec3(176, 90, 254)) { col.rgb = fx(1, vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.3529, 0.8471), vec3(0.4784, 0.3529, 1.0000), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(44, 22, 63)) { col.rgb = fx(1, vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.3529, 0.8471), vec3(0.4784, 0.3529, 1.0000), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 58, 59)) { col.rgb = fx(0, vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 14, 14)) { col.rgb = fx(0, vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(74, 184, 254)) { col.rgb = fx(0, vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(18, 46, 63)) { col.rgb = fx(0, vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(88, 208, 107)) { col.rgb = fx(0, vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(22, 52, 26)) { col.rgb = fx(0, vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 170, 50)) { col.rgb = fx(0, vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 42, 12)) { col.rgb = fx(0, vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(85, 255, 86)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(21, 63, 21)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(85, 255, 254)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(21, 63, 63)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 85, 86)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 0.3333), vec3(1.0000, 0.6039, 0.2275), vec3(1.0000, 0.2275, 0.4157), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 21, 21)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 0.3333), vec3(1.0000, 0.6039, 0.2275), vec3(1.0000, 0.2275, 0.4157), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 85, 254)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 1.0000), vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.5412, 1.0000), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 21, 63)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 1.0000), vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.5412, 1.0000), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 210, 59)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 52, 14)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(176, 91, 255)) { col.rgb = fx(1, vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.3529, 0.8471), vec3(0.4784, 0.3529, 1.0000), 0.600, 0.300, x, t, top); }
    else if (c == ivec3(44, 22, 63)) { col.rgb = fx(1, vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.3529, 0.8471), vec3(0.4784, 0.3529, 1.0000), 0.600, 0.300, x, t, top) * 0.25; }
    else if (c == ivec3(255, 59, 58)) { col.rgb = fx(0, vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(63, 14, 14)) { col.rgb = fx(0, vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), vec3(1.0000, 0.2275, 0.2275), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(74, 185, 255)) { col.rgb = fx(0, vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(18, 46, 63)) { col.rgb = fx(0, vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), vec3(0.2902, 0.7216, 1.0000), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(88, 209, 106)) { col.rgb = fx(0, vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(22, 52, 26)) { col.rgb = fx(0, vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), vec3(0.3451, 0.8157, 0.4157), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(255, 171, 51)) { col.rgb = fx(0, vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(63, 42, 12)) { col.rgb = fx(0, vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), vec3(1.0000, 0.6667, 0.2000), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(86, 255, 85)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(21, 63, 21)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), vec3(0.3333, 1.0000, 0.3333), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(86, 255, 255)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), 0.700, 0.350, x, t, top); }
    else if (c == ivec3(21, 63, 63)) { col.rgb = fx(0, vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), vec3(0.3333, 1.0000, 1.0000), 0.700, 0.350, x, t, top) * 0.25; }
    else if (c == ivec3(255, 86, 85)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 0.3333), vec3(1.0000, 0.6039, 0.2275), vec3(1.0000, 0.2275, 0.4157), 0.600, 0.300, x, t, top); }
    else if (c == ivec3(63, 21, 21)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 0.3333), vec3(1.0000, 0.6039, 0.2275), vec3(1.0000, 0.2275, 0.4157), 0.600, 0.300, x, t, top) * 0.25; }
    else if (c == ivec3(255, 86, 255)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 1.0000), vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.5412, 1.0000), 0.600, 0.300, x, t, top); }
    else if (c == ivec3(63, 21, 63)) { col.rgb = fx(1, vec3(1.0000, 0.3333, 1.0000), vec3(0.6902, 0.3529, 1.0000), vec3(1.0000, 0.5412, 1.0000), 0.600, 0.300, x, t, top) * 0.25; }
    else if (c == ivec3(255, 211, 58)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), 0.600, 1.000, x, t, top); }
    else if (c == ivec3(63, 52, 14)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), vec3(1.0000, 0.8235, 0.2275), 0.600, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 207, 59)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 51, 14)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 1.000, 1.000, x, t, top) * 0.25; }
    else if (c == ivec3(255, 207, 60)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.800, 0.500, x, t, top); }
    else if (c == ivec3(63, 51, 15)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.800, 0.500, x, t, top) * 0.25; }
    else if (c == ivec3(255, 207, 61)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.800, 0.600, x, t, top); }
    else if (c == ivec3(63, 51, 15)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.800, 0.600, x, t, top) * 0.25; }
    else if (c == ivec3(255, 122, 59)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.700, 0.600, x, t, top); }
    else if (c == ivec3(63, 30, 14)) { col.rgb = fx(1, vec3(1.0000, 0.8118, 0.2275), vec3(1.0000, 0.4784, 0.2275), vec3(1.0000, 0.3529, 0.5412), 0.700, 0.600, x, t, top) * 0.25; }
    else if (c == ivec3(255, 176, 59)) { col.rgb = fx(0, vec3(1.0000, 0.6902, 0.2275), vec3(1.0000, 0.6902, 0.2275), vec3(1.0000, 0.6902, 0.2275), 0.600, 0.450, x, t, top); }
    else if (c == ivec3(63, 44, 14)) { col.rgb = fx(0, vec3(1.0000, 0.6902, 0.2275), vec3(1.0000, 0.6902, 0.2275), vec3(1.0000, 0.6902, 0.2275), 0.600, 0.450, x, t, top) * 0.25; }
    else if (c == ivec3(234, 234, 245)) { col.rgb = fx(0, vec3(0.9490, 0.9490, 1.0000), vec3(0.9490, 0.9490, 1.0000), vec3(0.9490, 0.9490, 1.0000), 0.500, 0.800, x, t, top); }
    else if (c == ivec3(58, 58, 61)) { col.rgb = fx(0, vec3(0.9490, 0.9490, 1.0000), vec3(0.9490, 0.9490, 1.0000), vec3(0.9490, 0.9490, 1.0000), 0.500, 0.800, x, t, top) * 0.25; }
    else if (c == ivec3(255, 138, 222)) { col.rgb = fx(2, vec3(1.0000, 0.5412, 0.8745), vec3(1.0000, 0.5412, 0.8745), vec3(1.0000, 0.5412, 0.8745), 1.000, 1.000, x, t, top); }
    else if (c == ivec3(63, 34, 55)) { col.rgb = fx(2, vec3(1.0000, 0.5412, 0.8745), vec3(1.0000, 0.5412, 0.8745), vec3(1.0000, 0.5412, 0.8745), 1.000, 1.000, x, t, top) * 0.25; }

    gl_Position = pos;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
