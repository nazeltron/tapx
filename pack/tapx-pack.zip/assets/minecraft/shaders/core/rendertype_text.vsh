#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

// TapX: animated text colours (see TextFx.kt). Everything else is vanilla.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 tapxHue(float h) {
    return clamp(abs(mod(h * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
}

// a -> b -> c -> a, p in [0, 1)
vec3 tapxLoop(vec3 a, vec3 b, vec3 c, float p) {
    float q = fract(p) * 3.0;
    if (q < 1.0) return mix(a, b, smoothstep(0.0, 1.0, q));
    if (q < 2.0) return mix(b, c, smoothstep(0.0, 1.0, q - 1.0));
    return mix(c, a, smoothstep(0.0, 1.0, q - 2.0));
}

// more vibrant: push the colour away from its own grey
vec3 tapxVivid(vec3 c, float amount) {
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    return clamp(mix(vec3(l), c, amount), 0.0, 1.0);
}

vec3 fx(int kind, vec3 c1, vec3 c2, vec3 c3, float speed, float shine, float x, float t, bool top) {
    vec3 base;
    if (kind == 2) {
        base = tapxHue(t * 0.12 * speed);                           // rainbow, whole word at once
    } else if (kind == 1) {
        base = tapxLoop(c1, c2, c3, t * 0.12 * speed);              // fades through its colours
    } else {
        base = c1;
    }
    base = tapxVivid(base, 1.3);
    base *= 0.94 + 0.06 * sin(t * 2.2 * speed);                    // gentle breathing glow
    // candy gloss: each letter lighter at the top, deeper at the bottom
    base = top ? mix(base, vec3(1.0), 0.38) : base * 0.78;
    // soft shine sweeping left to right every few seconds
    float s = fract(x / 260.0 - t * 0.28 * speed);
    float band = smoothstep(0.0, 0.06, s) * (1.0 - smoothstep(0.06, 0.16, s));
    return mix(base, vec3(1.0), band * 0.55 * shine);
}

// how much a letter at x is swollen right now (0..1): a soft bump rippling along the text
float tapxPuff(float x, float t, float speed) {
    float p = fract(t * 0.45 * speed - x / 160.0);
    return exp(-pow((p - 0.5) * 7.0, 2.0));
}

void main() {
    vec4 pos = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 col = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    float t = GameTime * 1200.0;
    float gs = max(1.0, floor(min(ScreenSize.x / 320.0, ScreenSize.y / 240.0)));
    float x = (pos.x / pos.w * 0.5 + 0.5) * ScreenSize.x / gs;
    // glyph quads are drawn top-left, bottom-left, bottom-right, top-right
    int corner = gl_VertexID % 4;
    bool top = corner == 0 || corner == 3;
    float puff = 0.0;
    if (c == ivec3(166, 60, 254)) { col.rgb = fx(1, vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.2353, 0.8235), vec3(0.4353, 0.2353, 1.0000), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(41, 15, 63)) { col.rgb = fx(1, vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.2353, 0.8235), vec3(0.4353, 0.2353, 1.0000), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 46, 48)) { col.rgb = fx(0, vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 11, 12)) { col.rgb = fx(0, vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(47, 168, 252)) { col.rgb = fx(0, vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(11, 42, 63)) { col.rgb = fx(0, vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(63, 224, 94)) { col.rgb = fx(0, vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(15, 56, 23)) { col.rgb = fx(0, vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 164, 27)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 41, 6)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(61, 254, 76)) { col.rgb = fx(0, vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(15, 63, 19)) { col.rgb = fx(0, vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(47, 243, 252)) { col.rgb = fx(0, vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(11, 60, 63)) { col.rgb = fx(0, vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 47, 66)) { col.rgb = fx(1, vec3(1.0000, 0.1804, 0.2431), vec3(1.0000, 0.5412, 0.0706), vec3(1.0000, 0.1804, 0.5412), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 11, 16)) { col.rgb = fx(1, vec3(1.0000, 0.1804, 0.2431), vec3(1.0000, 0.5412, 0.0706), vec3(1.0000, 0.1804, 0.5412), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 62, 241)) { col.rgb = fx(1, vec3(1.0000, 0.2353, 0.9412), vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.4784, 1.0000), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 15, 60)) { col.rgb = fx(1, vec3(1.0000, 0.2353, 0.9412), vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.4784, 1.0000), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 212, 28)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 53, 7)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(166, 62, 252)) { col.rgb = fx(1, vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.2353, 0.8235), vec3(0.4353, 0.2353, 1.0000), 0.600, 0.350, x, t, top); puff = 0.40; }
    else if (c == ivec3(41, 15, 63)) { col.rgb = fx(1, vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.2353, 0.8235), vec3(0.4353, 0.2353, 1.0000), 0.600, 0.350, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 48, 50)) { col.rgb = fx(0, vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(63, 12, 12)) { col.rgb = fx(0, vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), vec3(1.0000, 0.1804, 0.1804), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(47, 171, 254)) { col.rgb = fx(0, vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(11, 42, 63)) { col.rgb = fx(0, vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), vec3(0.1843, 0.6588, 1.0000), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(63, 227, 92)) { col.rgb = fx(0, vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(15, 56, 23)) { col.rgb = fx(0, vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), vec3(0.2471, 0.8784, 0.3529), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 166, 29)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(63, 41, 7)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(61, 252, 78)) { col.rgb = fx(0, vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(15, 63, 19)) { col.rgb = fx(0, vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), vec3(0.2392, 1.0000, 0.2902), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(47, 246, 254)) { col.rgb = fx(0, vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), 0.700, 0.400, x, t, top); puff = 0.40; }
    else if (c == ivec3(11, 61, 63)) { col.rgb = fx(0, vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), vec3(0.1843, 0.9490, 1.0000), 0.700, 0.400, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 50, 64)) { col.rgb = fx(1, vec3(1.0000, 0.1804, 0.2431), vec3(1.0000, 0.5412, 0.0706), vec3(1.0000, 0.1804, 0.5412), 0.600, 0.350, x, t, top); puff = 0.40; }
    else if (c == ivec3(63, 12, 16)) { col.rgb = fx(1, vec3(1.0000, 0.1804, 0.2431), vec3(1.0000, 0.5412, 0.0706), vec3(1.0000, 0.1804, 0.5412), 0.600, 0.350, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 64, 243)) { col.rgb = fx(1, vec3(1.0000, 0.2353, 0.9412), vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.4784, 1.0000), 0.600, 0.350, x, t, top); puff = 0.40; }
    else if (c == ivec3(63, 16, 60)) { col.rgb = fx(1, vec3(1.0000, 0.2353, 0.9412), vec3(0.6510, 0.2353, 1.0000), vec3(1.0000, 0.4784, 1.0000), 0.600, 0.350, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 214, 30)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), 0.600, 1.000, x, t, top); puff = 0.40; }
    else if (c == ivec3(63, 53, 7)) { col.rgb = fx(2, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.8235, 0.1020), 0.600, 1.000, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 215, 27)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 53, 6)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }
    else if (c == ivec3(255, 215, 28)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.800, 0.500, x, t, top); puff = 0.00; }
    else if (c == ivec3(63, 53, 7)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.800, 0.500, x, t, top) * 0.25; puff = 0.00; }
    else if (c == ivec3(255, 215, 29)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.800, 0.600, x, t, top); puff = 0.60; }
    else if (c == ivec3(63, 53, 7)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.800, 0.600, x, t, top) * 0.25; puff = 0.60; }
    else if (c == ivec3(255, 215, 30)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.700, 0.600, x, t, top); puff = 0.50; }
    else if (c == ivec3(63, 53, 7)) { col.rgb = fx(1, vec3(1.0000, 0.8235, 0.1020), vec3(1.0000, 0.4784, 0.0706), vec3(1.0000, 0.2392, 0.5412), 0.700, 0.600, x, t, top) * 0.25; puff = 0.50; }
    else if (c == ivec3(255, 169, 27)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 0.600, 0.450, x, t, top); puff = 0.30; }
    else if (c == ivec3(63, 42, 6)) { col.rgb = fx(0, vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), vec3(1.0000, 0.6392, 0.1020), 0.600, 0.450, x, t, top) * 0.25; puff = 0.30; }
    else if (c == ivec3(244, 246, 253)) { col.rgb = fx(0, vec3(0.9569, 0.9412, 1.0000), vec3(0.9569, 0.9412, 1.0000), vec3(0.9569, 0.9412, 1.0000), 0.500, 0.800, x, t, top); puff = 0.40; }
    else if (c == ivec3(61, 61, 63)) { col.rgb = fx(0, vec3(0.9569, 0.9412, 1.0000), vec3(0.9569, 0.9412, 1.0000), vec3(0.9569, 0.9412, 1.0000), 0.500, 0.800, x, t, top) * 0.25; puff = 0.40; }
    else if (c == ivec3(255, 96, 226)) { col.rgb = fx(2, vec3(1.0000, 0.3529, 0.8745), vec3(1.0000, 0.3529, 0.8745), vec3(1.0000, 0.3529, 0.8745), 1.000, 1.000, x, t, top); puff = 1.00; }
    else if (c == ivec3(63, 24, 56)) { col.rgb = fx(2, vec3(1.0000, 0.3529, 0.8745), vec3(1.0000, 0.3529, 0.8745), vec3(1.0000, 0.3529, 0.8745), 1.000, 1.000, x, t, top) * 0.25; puff = 1.00; }

    if (puff > 0.0) {
        // grow the letter around its centre: each corner moves outwards (up to ~0.8 GUI pixels)
        float d = puff * 0.8 * gs * tapxPuff(x, t, 1.0);
        float dx = (corner == 0 || corner == 1) ? -d : d;
        float dy = top ? d : -d;
        pos.x += dx * 2.0 / ScreenSize.x * pos.w;
        pos.y += dy * 2.0 / ScreenSize.y * pos.w;
    }
    gl_Position = pos;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
